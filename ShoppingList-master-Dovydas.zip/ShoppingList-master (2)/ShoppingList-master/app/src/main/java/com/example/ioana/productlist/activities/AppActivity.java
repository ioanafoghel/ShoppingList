package com.example.ioana.productlist.activities;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import com.example.ioana.productlist.R;
import com.example.ioana.productlist.model.ProductList;
import com.example.ioana.productlist.service.Service;
import com.example.ioana.productlist.storage.Storage;

import java.util.ArrayList;

/**
 * Created by Ioana on 02/03/2016.
 */
public class AppActivity extends AppCompatActivity {
    Button button;
    Button buttonShop;

    //######added
    private SharedPreferences sharedPreferences;
    private static final String BASE64 = "Base64";
    //######

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //######added
        loadStorage();
        addListenerOnButton();
    }

    public void addListenerOnButton() {
        final Context context = this;
        button = (Button) findViewById(R.id.createButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, PopUpActivity.class);
                startActivity(intent);
            }
        });
        buttonShop = (Button) findViewById(R.id.shopsButton);
        buttonShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ActivityShop.class);
                startActivity(intent);
            }
        });
    }

    //######added
    public void loadStorage(){
        sharedPreferences = getPreferences(Context.MODE_PRIVATE);
        String base64 = sharedPreferences.getString(BASE64, null);
        if (base64 != null)
            Service.toObject(base64);
    }

}