package com.example.ioana.productlist;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ioana.productlist.model.Product;
import com.example.ioana.productlist.model.ProductList;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dovydas on 3/5/2016.
 */
public class ProductsToBuyAdapter extends ArrayAdapter<Product> {

    LayoutInflater inflater;
    Context c;
    public ProductsToBuyAdapter(Context context,int resource, ArrayList<Product> products) {
        super(context,resource, products);
        this.c=context;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        if (convertView == null) {
            inflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.products_to_buy_adapter, null);

        }

        ImageView textView1 = (ImageView) convertView.findViewById(R.id.imageView1);
        TextView textView2 = (TextView) convertView.findViewById(R.id.productPrice);
        TextView textView3 = (TextView) convertView.findViewById(R.id.offerPrice);
        TextView textView4 = (TextView) convertView.findViewById(R.id.productName);
        TextView textView5 = (TextView) convertView.findViewById(R.id.productDescription);
        final Product product = (Product) getItem(position);

        textView1.setImageResource(product.getImg());
        textView2.setText("Price: " + product.getPrice());
        textView3.setText("Offer: "+product.getOfferPrice());
        textView4.setText(product.getName());
        textView5.setText(product.getDescription());

        return convertView;
    }
}
