package com.example.ioana.productlist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.ioana.productlist.model.ProductList;

import java.util.List;

/**
 * Created by Ioana on 05/03/2016.
 */
public class ProductListAdapter extends ArrayAdapter<ProductList> {
    LayoutInflater inflater;
    Context c;

    public ProductListAdapter(Context context, int resource, List<ProductList> lists) {
        super(context, resource, lists);
        this.c = context;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.productlist, null);
        }
        TextView textView = (TextView) convertView.findViewById(R.id.basketName);
        final ProductList list = (ProductList) getItem(position);

        textView.setText(list.getName());
        return convertView;
    }
}
