package com.example.ioana.productlist.activities;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.ioana.productlist.ProductListAdapter;
import com.example.ioana.productlist.R;
import com.example.ioana.productlist.service.Service;

/**
 * Created by Ioana on 05/03/2016.
 */
public class ProductListsActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private static final String BASE64 = "Base64";
    private ActionMode myActionMode;
    private int selectedPosition;
    private ListView listView;

    @Override
   protected void onCreate(Bundle savedInstanceState) {
        final Context context = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productlist);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home_icon);

        sharedPreferences = getPreferences(Context.MODE_PRIVATE);
        String base64 = sharedPreferences.getString(BASE64, null);

        listView = (ListView) findViewById(R.id.listslistView);
        final ProductListAdapter productListAdapter
                = new ProductListAdapter(this, 0, Service.getProductLists());
        listView.setAdapter(productListAdapter);
        listView.setLongClickable(true);
        //((BaseAdapter) listView.getAdapter()).notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent,
                                    View view, int position, long id) {

                Intent shopInfo = new Intent(context, DoShopping.class);
                shopInfo.putExtra("listIndex", position);
                startActivity(shopInfo);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                selectedPosition = position;
                registerForContextMenu(parent);
                openContextMenu(parent);
                return true;
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menu_context, menu);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.delete:
                Service.getProductLists().remove(selectedPosition);
                Toast.makeText(this, "List removed",
                        Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    @Override
    public void onContextMenuClosed(Menu menu){
        ( (ProductListAdapter)listView.getAdapter()).notifyDataSetChanged();
    }




    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @TargetApi(Build.VERSION_CODES.GINGERBREAD)
    @Override
    protected void onStop() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String base64 = Service.toString(Service.getProductLists());
        editor.putString(BASE64, base64);
        editor.apply();
        System.out.println("### shopping lists saved to memory ###");
        super.onStop();
    }
}



