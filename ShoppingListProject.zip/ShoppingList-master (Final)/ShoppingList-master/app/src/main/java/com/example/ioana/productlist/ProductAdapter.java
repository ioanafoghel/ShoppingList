package com.example.ioana.productlist;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ioana.productlist.activities.PopUpMenuActivity;
import com.example.ioana.productlist.model.*;
import com.example.ioana.productlist.service.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ioana on 24/02/2016.
 */

public class ProductAdapter extends ArrayAdapter<Product> {
    LayoutInflater inflater;
    Context c;
    // color for marking
    final String color="#ccccff";

    public ProductAdapter(Context context,int resource, List<Product> products) {
       super(context,resource, products);
       this.c=context;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        final ViewHolder viewHolder;
      if (convertView==null) {
            inflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.product, null);
          viewHolder= new ViewHolder();
          final ImageView textView1 = (ImageView) convertView.findViewById(R.id.imageView1);
          final TextView textView2 = (TextView) convertView.findViewById(R.id.productName);
          final TextView textView3 = (TextView) convertView.findViewById(R.id.productDescription);
          final TextView textView4 = (TextView) convertView.findViewById(R.id.productPrice);
          final TextView textView5 = (TextView) convertView.findViewById(R.id.offerPrice);
          final TextView textView6 = (TextView) convertView.findViewById(R.id.numberTextId);
          ImageView imgBtn= (ImageView) convertView.findViewById(R.id.imageButton);
          Button btnPlus= (Button) convertView.findViewById(R.id.plusButton);
          Button btnMinus= (Button) convertView.findViewById(R.id.minusButton);
          viewHolder.img=imgBtn;
          viewHolder.btnMinus=btnMinus;
          viewHolder.btnPlus=btnPlus;
          viewHolder.t1=textView1;
          viewHolder.t2=textView2;
          viewHolder.t3=textView3;
          viewHolder.t4=textView4;
          viewHolder.t5=textView5;
          viewHolder.t6=textView6;

          convertView.setTag(viewHolder);
        }else{
          viewHolder = (ViewHolder) convertView.getTag();
      }
        final Product product = (Product) getItem(position);

        int i = Service.getProductLists().size();
        ArrayList<Product> p = Service.getProductLists().get(i - 1).getProductsInList();
        boolean found=false;
        for (Product d: p){
            if (d.getName().equals(product.getName())){
                convertView.setBackgroundColor(Color.parseColor(color));
                viewHolder.t6.setText(""+(int)(d.getPrice()/product.getPrice()));
                found=true;
                break;
            }
            if (!found)
                convertView.setBackgroundColor(Color.parseColor("#ffffff"));
                viewHolder.t6.setText(""+1);
        }
        viewHolder.t1.setImageResource(product.getImg());
        viewHolder.t2.setText(product.getName());
        viewHolder.t3.setText(product.getDescription());
        viewHolder.t4.setText("Price: " + product.getPrice());
        viewHolder.t5.setText("Offer: " + product.getOfferPrice());

        viewHolder.img.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(c, PopUpMenuActivity.class);
                c.startActivity(intent);
            }
        });

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = Service.getProductLists().size();
                // retriving the newest created shopping list.
                ArrayList<Product> p = Service.getProductLists().get(i - 1).getProductsInList();
                boolean found= false;
                for (Product d: p){
                    if (d.getName().equals(product.getName())){
                        found = true;
                        p.remove(d);
                        v.setBackgroundColor(Color.parseColor("#ffffff"));
                        break;
                    }
                }
                if (!found){
                    Product addProduct=product.copy();

                    String[] price = ((String)viewHolder.t4.getText()).split(" ");
                    String[] offer = ((String) viewHolder.t5.getText()).split(" ");
                    double offer1 = Double.parseDouble(offer[1]);
                    double price1 = Double.parseDouble(price[1]);
                    addProduct.setDescription(((String) viewHolder.t3.getText()));
                    addProduct.setOfferPrice(offer1);
                    addProduct.setPrice(price1);
                    p.add(addProduct);
                    v.setBackgroundColor(Color.parseColor(color));
                }
            }
        });

        viewHolder.btnPlus.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String[] standardVolume = product.getDescription().split(" ");
                String[] selectedVolume = ((String) viewHolder.t3.getText()).split(" ");
                double standard = Double.parseDouble(standardVolume[0]);
                double selected = Double.parseDouble(selectedVolume[0]) + standard;
                viewHolder.t3.setText(selected + " " + standardVolume[1]);
                //updates offer and normal prices displayed
                viewHolder.t4.setText("Price: " + Math.round((selected / standard * product.getPrice()) * 100d) / 100d);
                viewHolder.t5.setText("Offer: " + Math.round((selected / standard * product.getOfferPrice()) * 100d) / 100d);
                viewHolder.t6.setText("" + (Integer.parseInt((String) viewHolder.t6.getText()) + 1));
            }
        });
        viewHolder.btnMinus.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String[] standardVolume=product.getDescription().split(" ");
                String[] selectedVolume=((String)viewHolder.t3.getText()).split(" ");
                double standard=Double.parseDouble(standardVolume[0]);
                double selected=Double.parseDouble(selectedVolume[0]);
                if (standard<selected) {
                    selected = selected - standard;
                    viewHolder.t3.setText(selected + " " + standardVolume[1]);
                    //updates offer and normal prices displayed
                    viewHolder.t4.setText("Price: "+Math.round((selected/standard*product.getPrice())* 100d)/100d);
                    viewHolder.t5.setText("Offer: "+Math.round((selected / standard * product.getOfferPrice())* 100d)/100d);
                    viewHolder.t6.setText(""+(Integer.parseInt((String) viewHolder.t6.getText()) - 1));
                }
            }
        });

        return convertView;
    }

    static class ViewHolder{
        TextView t2, t3, t4, t5, t6;
        Button btnPlus, btnMinus;
        ImageView img, t1;
    }
}