package com.example.ioana.productlist.storage;

import com.example.ioana.productlist.R;
import com.example.ioana.productlist.model.Product;
import com.example.ioana.productlist.model.ProductList;
import com.example.ioana.productlist.model.Shop;
import com.example.ioana.productlist.service.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ioana on 04/03/2016.
 */
public class Storage {
    private ArrayList<Product> products = new ArrayList<>();
    private ArrayList<Shop> shops = new ArrayList<>();
    private ArrayList<ProductList> productLists = new ArrayList<>();
    private static Storage uniqueInstance;

    private Storage() {
    }

    public static Storage getInstance() {
        if (uniqueInstance == null) {
            uniqueInstance = new Storage();
            uniqueInstance.createSomeObjects();
        }
        return uniqueInstance;
    }


    public ArrayList<Product> getProducts() {
        return products;
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void removeProduct(Product product) {
        products.remove(product);
    }

    public void removeProduct(int productIndex) {
        products.remove(productIndex);
    }

    public Product createProduct(int img, String name, String description, Double price, Double offerPrice, int unit) {
        Product product = new Product(img, name, description, price, offerPrice, unit);
        uniqueInstance.addProduct(product);
        return product;
    }

    public void updateProduct(Product product, int img, String name, String description, Double price, Double offerPrice, int unit) {
        product.setImg(img);
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        product.setOfferPrice(offerPrice);
        product.setUnit(unit);
    }

    public ArrayList<ProductList> getProductLists() {
        return productLists;
    }

    public void addProductList(ProductList productList) {
        productLists.add(productList);
    }

    public void removeProductList(ProductList productList) {
        productLists.remove(productList);
    }

    public void removeProductList(int productIndex) {
        productLists.remove(productIndex);
    }

    public ProductList createProductList(String name) {
        ProductList productList = new ProductList(name);
        uniqueInstance.addProductList(productList);
        return productList;
    }

    public void updateProductList(ProductList productList, String name) {
        productList.setName(name);
    }

    public ArrayList<Shop> getShops() {
        return shops;
    }

    public void addShop(Shop shop) {
        shops.add(shop);
    }

    public void removeShop(Shop shop) {
        shops.remove(shop);
    }

    public Shop createShop(int img, String name, String address) {
        Shop shop = new Shop(img, name, address);
        uniqueInstance.addShop(shop);
        return shop;
    }

    public void updateShop(Shop shop, int img, String name, String address) {
        shop.setShopImg(img);
        shop.setName(name);
        shop.setAddress(address);
    }

    public ProductList getProductAtIndex(int listIndex) {
        return productLists.get(listIndex);
    }


    public void createSomeObjects() {
        String[] productNames = {"Kinder Bueno", "Kinder Chocolate 4", "Kinder Chocolate 8", "Kinder Country", "Kinder Delice", "Kinder Pinguin", "Kinder Schoko-Bons", "Kinder Surprise"};
        String[] productDescriptions = {"23 g", "100 g", "200 g", "30 g", "50 g", "100 g", "230 g", "12 g"};
        double[] productPrice = {15, 30, 40, 20, 23.9, 50, 50, 35};
        double[] offers = {12, 25, 38, 18, 20.9, 30, 30, 32};
        int[] imgs = {R.drawable.kinder_bueno, R.drawable.kinder_chocolate4, R.drawable.kinder_chocolate8, R.drawable.kinder_country, R.drawable.kinder_delice, R.drawable.kinder_pinguin, R.drawable.kinder_schoko_bons, R.drawable.kinder_surprise};
        String[] shopNames = {"Aldi", "Bilka", "FØtex", "Lidl", "Rema 1000", "Netto"};
        String[] shopsAddresses = {"AAaa", "BBb", "Ccc", "Ddd", "Eee", "ffff"};
        int[] shopsImgs = {R.drawable.aldi_icon, R.drawable.bilka_icon, R.drawable.fotex_icon, R.drawable.lidl_icon, R.drawable.rema_icon, R.drawable.netto_icon};
        String[] productListNames = {"Saturday snack", "Halloween  candy", "Kids rewards"};


        Shop s1 = createShop(R.drawable.aldi_icon, "Aldi", "Christian X's Vej 112, 8260 Viby J");
        Shop s2 = createShop(R.drawable.bilka_icon, "Bilka", "Gudrunsvej 7, 8220 Brabrand");
        Shop s3 = createShop(R.drawable.fotex_icon, "FØtex", "Viborgvej 165, 8210");
        Shop s4 = createShop(R.drawable.lidl_icon, "Lidl", "Skejbyvej 499, 8200 Skejby");
        Shop s5 = createShop(R.drawable.rema_icon, "Rema 1000", "Voldbjergvej 20, 8240 Risskov");
        Shop s6 = createShop(R.drawable.netto_icon, "Netto", "Damagervej 20, 8260 Viby J");

        Product p1 = createProduct(R.drawable.kinder_bueno, "Kinder bueno", "23 g", 12.3, 10.0, 1);
        Product p2= createProduct(R.drawable.kinder_chocolate8, "Kinder Choco8", "20 g", 12.3, 10.0, 1);
        Product p3= createProduct(R.drawable.kinder_chocolate4, "Kinder Cho4", "1 vnt", 8.0, 7.0, 1);
        Product p4= createProduct(R.drawable.kinder_country, "Country", "20 g", 12.0, 12.0, 1);
        Product p5 = createProduct(R.drawable.kinder_delice, "Kinder dlc", "23 g", 12.0, 10.0, 1);
        Product p6= createProduct(R.drawable.kinder_bueno, "Kinder B", "20 g", 10.0, 9.0, 1);
        Product p7= createProduct(R.drawable.kinder_pinguin, "Kinder Bu", "1 vnt", 12.3, 10.0, 1);
        Product p8= createProduct(R.drawable.kinder_schoko_bons, "Choko", "1 vnt", 15.0, 12.0, 1);
        Product p9= createProduct(R.drawable.kinder_schoko_bons, "Kinder bons", "23 g", 15.5, 10.0, 1);
        Product p10= createProduct(R.drawable.kinder_chocolate8, "Kinder 8", "20 g", 12.3, 10.0, 1);
        Product p11= createProduct(R.drawable.kinder_surprise, "surprise", "100 g", 12.0, 9.0, 1);

        for (Shop e: Service.getShops()) {
            e.addProductInShop(p1);
            e.addProductInShop(p2);
            e.addProductInShop(p3);
            e.addProductInShop(p4);
            e.addProductInShop(p5);
            e.addProductInShop(p6);
            e.addProductInShop(p7);
            e.addProductInShop(p8);
            e.addProductInShop(p9);
            e.addProductInShop(p10);
            e.addProductInShop(p11);
        }

        ProductList ggg=new ProductList("Kinderiu listas");
        ProductList ggg1=new ProductList("Only two items list");
        ggg.addProductInList(p1);
        ggg.addProductInList(p2);
        ggg.addProductInList(p3);
        ggg.addProductInList(p8);
        ggg.addProductInList(p9);
        ggg.addProductInList(p11);
        ggg1.addProductInList(p3);
        ggg1.addProductInList(p8);
        Storage.getInstance().getProductLists().add(ggg1);
        Storage.getInstance().getProductLists().add(ggg);
    }

    public void addProductToList(int listIndex, int shopIndex, int productIndex) {
        ProductList productList = getProductLists().get(listIndex);
        Shop shop = getShops().get(shopIndex);
        Product product = shop.getProductsInShop().get(productIndex);
        productList.addProductInList(product);
    }

}