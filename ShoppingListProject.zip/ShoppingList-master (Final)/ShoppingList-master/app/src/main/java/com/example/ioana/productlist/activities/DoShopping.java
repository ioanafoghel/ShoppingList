package com.example.ioana.productlist.activities;


import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.ioana.productlist.ProductListAdapter;
import com.example.ioana.productlist.ProductsToBuyAdapter;
import com.example.ioana.productlist.R;
import com.example.ioana.productlist.model.Product;
import com.example.ioana.productlist.model.ProductList;
import com.example.ioana.productlist.service.Service;

import java.util.ArrayList;

public class DoShopping extends AppCompatActivity {
    ArrayList<Product> boughtProducts= new ArrayList<Product>();
    int listIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_do_shopping);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home_icon);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            listIndex = extras.getInt("listIndex");
        }
        ProductList value=Service.getProductsForList(listIndex);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home_icon);
        TextView totalPrice=(TextView) findViewById(R.id.normalPrice);
        double sum=0;
        for (Product p:value.getProductsInList()){
            sum+=p.getOfferPrice();
        }
        totalPrice.setText(""+sum);
        final TextView selectedPrice=(TextView) findViewById(R.id.currentPrice);
        selectedPrice.setText("0");
        final ListView listView = (ListView) findViewById(R.id.productListToBuy);

        ProductsToBuyAdapter basketsArrayAdapter
                = new ProductsToBuyAdapter(this, R.layout.products_to_buy_adapter, value.getProductsInList());
        listView.setAdapter(basketsArrayAdapter);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent,
                                    View view, int position, long id) {
                Product product = (Product)listView.getAdapter().getItem(position);
                if (boughtProducts.contains(product)){
                    boughtProducts.remove(product);
                    double sum=0;
                    for (Product p:boughtProducts){
                        sum+=p.getOfferPrice();
                    }
                    selectedPrice.setText(""+sum);
                    view.setBackgroundColor(Color.WHITE);
                }else{
                    boughtProducts.add(product);
                    double sum=0;
                    for (Product p:boughtProducts){
                        sum+=p.getOfferPrice();
                    }
                    selectedPrice.setText("" + sum);
                    view.setBackgroundColor(Color.parseColor("#ccccff"));
                }
            }
        });

    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

